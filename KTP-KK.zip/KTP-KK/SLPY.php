<?php
$white = "\e[97m";
$black = "\e[30m\e[1m";
$yellow = "\e[93m";
$orange = "\e[38;5;208m";
$blue   = "\e[34m";
$lblue  = "\e[36m";
$cln    = "\e[0m";
$green  = "\e[92m";
$fgreen = "\e[32m";
$red    = "\e[91m";
$magenta = "\e[35m";
$bluebg = "\e[44m";
$lbluebg = "\e[106m";
$greenbg = "\e[42m";
$lgreenbg = "\e[102m";
$yellowbg = "\e[43m";
$lyellowbg = "\e[103m";
$redbg = "\e[101m";
$grey = "\e[37m";
$cyan = "\e[36m";
$bold   = "\e[1m";
function kkktp_banner(){
  echo "\e[92;1m
__  ______  _     ___ ___ _____
\ \/ /  _ \| |   / _ \_ _|_   _|
 \  /| |_) | |  | | | | |  | |
 /  \|  __/| |__| |_| | |  | |
/_/\_\_|   |_____\___/___| |_|

 ║ Coded by:  ./SLPY     ║ ║
 ║ Team : LUCIFER XPLOIT ║ ║
  \n";
}
?> 
